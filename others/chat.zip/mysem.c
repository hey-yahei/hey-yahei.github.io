/*
 * 嵌入式操作系统实验4 —— 多进程通信综合应用
 ****************************************************
 * 本文件定义了信号量的相关数据结构与操作
 ****************************************************
 * 修改时间：2017-6-12 12:40:53
 ****************************************************
 * 作者：YaHei(zk)
 */

#include "myshm.h"          // 共享内存（shm）相关的数据结构与操作
#include "mysem.h"          // 信号量（sem）相关的数据结构与操作

// 创建或获取信号量
void semInit(void){
    int semid;      // 暂存信号量id
    union semun semarg;     // 暂存信号量的控制参数
    char flg_new = 0;   // 标志变量，指示这是第一个用户进程（需要新建信号量并初始化）

    // 创建或获取信息表的访问信号量（进程间共享）
    semid = semget(SEM_MSG_KEY, 1, 0666);
    if(semid < 0){
        if(errno == ENOENT){    // 共享内存不存在，需要新建
            flg_new = 1;    // 设置标志位，指示后续的初始化工作
            semid = semget(SEM_MSG_KEY, 1, 0666 | IPC_CREAT);    // 新建信号量集
            printf("created new semaphore %d\n", semid);
        }else{  // 其他错误
            perror("semget(msg)");
            exit(-1);
        }   
    }
    if(flg_new){    // 新建的信号量集，需要初始化
        printf("created semid %d\n", semid);
        semarg.val = 1;
        if (semctl(semid, 0, SETALL, &semarg) < 0){
            perror("semctl(msg)");
            exit(-1);
        }
    }else{  // 非新建的信号量集
        printf("created semid %d\n", semid);
    }
    semid_msg = semid;  // 将信号量集的id保存到全局变量

    // 创建或获取用户表的访问信号量
    semid = semget(SEM_USER_KEY, 1, 0666 | IPC_CREAT);
    if(semid < 0){  // 出错
        perror("semget(user)");
        exit(-1);
    }
    if(flg_new){    // 新建的信号量集，需要初始化
        printf("created semid %d\n", semid);
        semarg.val = 1;
        if (semctl(semid, 0, SETALL, &semarg) < 0){
            perror("semctl(user)");
            exit(-1);
        }
    }else{  // 非新建的信号量集
        printf("get semid %d\n", semid);
    }
    semid_user = semid;     // 将信号量集的id保存到全局变量
}

// 释放所有信号量
void semFree(void){
    union semun semarg;

    // 释放信息表的访问信号量
    if (semid_msg >= 0){
        if (semctl(semid_msg, 0, IPC_RMID, semarg) < 0){
            perror("free_resources: semid_msg");
        }
    }

    // 释放用户表的访问信号量
    if (semid_user >= 0){
        if (semctl(semid_user, 0, IPC_RMID, semarg) < 0){
            perror("free_resources: semid_user");
        }
    }
}

// PV操作（信号量加减1）
void semAccess(int semid, int increment){
    struct sembuf sops;

    sops.sem_num = 0;
    sops.sem_op  = increment;
    sops.sem_flg = SEM_UNDO;

    if(semop(semid, &sops, 1) < 0){
        perror("semop for semAccess");
    }

    return;
}

// 等待信息表的访问权
void shmMsgWait(void){
    semAccess(semid_msg, -1);
}

// 释放信息表的访问权
void shmMsgPost(void){
    semAccess(semid_msg, 1);
}

// 等待用户表的控制权
void shmUserWait(void){
    semAccess(semid_user, -1);
}

// 释放用户表的控制权
void shmUserPost(void){
    semAccess(semid_user, 1);
}