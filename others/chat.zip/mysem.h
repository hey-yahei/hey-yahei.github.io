#ifndef _MYSEM_H
#define _MYSEM_H

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

// 用户表、信息表两个共享内存的访问控制信号量的key
#define SEM_MSG_KEY  (key_t)1234
#define SEM_USER_KEY (key_t)4321

extern int shmid_user;
extern int shmid_msg;
extern shm_user_t *shm_users;
extern shm_msg_t  *shm_msgs;
extern int semid_user;
extern int semid_msg;

// 用于作为semctl的参数的联合体
union semun {
    int val;                    /* value for SETVAL */
    struct semid_ds *buf;       /* buffer for IPC_STAT, IPC_SET */
    unsigned short int *array;  /* array for GETALL, SETALL */
    struct seminfo *__buf;      /* buffer for IPC_INFO */
};

void semInit(void);
void semFree(void);
void semAccess(int semid, int increment);
void shmMsgWait(void);
void shmMsgPost(void);
void shmUserWait(void);
void shmUserPost(void);


#endif // ~~_MYSEM_H