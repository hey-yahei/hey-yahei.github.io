/*
 * 嵌入式操作系统实验4 —— 多进程通信综合应用
 ****************************************************
 * 本文件定义了共享内存的相关数据结构与操作
 ****************************************************
 * 修改时间：2017-6-12 12:40:53
 ****************************************************
 * 作者：YaHei(zk)
 */

#include "myshm.h"          // 共享内存（shm）相关的数据结构与操作
#include "mysem.h"          // 信号量（sem）相关的数据结构与操作

// 创建信息表和用户表
void shmInit(void){
    void *shared_memory = NULL;     // 暂存共享内存的指针
    int  shmid;             // 暂存共享内存的id
    char flg_new = 0;       // 标志变量，指示这是第一个用户进程（需要新建共享内存并初始化）

    // 创建信息表
    shmid = shmget(SHM_MSG_KEY, sizeof(shm_msg_t) * SHM_MSG_SIZE, 0666);    // 尝试获取已有的共享内存
    if(shmid == -1){    // 获取失败
        if(errno == ENOENT){    // 共享内存不存在，需要新建
            flg_new = 1;    // 设置标志位，指示后续的初始化工作
            shmid = shmget(SHM_MSG_KEY, sizeof(shm_msg_t) * SHM_MSG_SIZE, 0666 | IPC_CREAT);    // 新建共享内存
            printf("created new shared memory %d\n", shmid);
        }else{  // 其他错误
            perror("shmget(msg)");
            exit(-1);
        }        
    }
    shared_memory = shmat(shmid, NULL, 0);  // 将共享内存映射到进程内的空间
    if(shared_memory == (void *)-1){    // 映射出错
        perror("shmat(msg)");
        exit(-1); 
    }
    shmid_msg = shmid;      // 将共享内存的id保存到全局变量中
    shm_msgs = (shm_msg_t *)shared_memory;  // 将共享内存在进程内的映射地址保存到全局变量中
    printf("Memory msgs attached at %X\n", (int)shared_memory);
    

    // 创建用户表
    shmid = shmget(SHM_USER_KEY, sizeof(shm_user_t) * SHM_USER_SIZE, 0666); // 尝试获取已有的共享内存
    if(shmid == -1){    // 获取失败
        if(errno == ENOENT){       // 共享内存不存在，需要新建
            shmid = shmget(SHM_USER_KEY, sizeof(shm_user_t) * SHM_USER_SIZE, 0666 | IPC_CREAT); // 新建共享内存
            printf("created new shared memory %d\n", shmid);            
        }else{  // 其他错误
            perror("shmget(user)");
            exit(-1);
        }
    }
    shared_memory = shmat(shmid, NULL, 0);  // 将共享内存映射到进程内的空间
    if(shared_memory == (void *)-1){    // 映射出错
        perror("shmat(user)");
        exit(-1);
    }
    shmid_user = shmid;     // 将共享内存的id保存到全局变量中
    shm_users = (shm_user_t *)shared_memory;    // 将共享内存在进程内的映射地址保存到全局变量中
    printf("Memory users attached at %X\n", (int)shared_memory);

    // 对新建的共享内存进行初始化（msgs的dest、user的id都赋值为0）
    if(flg_new){   
        // 初始化信息表     
        for(int i = 0; i < SHM_MSG_SIZE; i++){
            shm_msgs[i].dest = 0;
        }

        // 初始化用户表
        for(int i = 0; i < SHM_USER_SIZE; i++){
            shm_users[i].id = 0;
        }
    }

    return;
}

// 解除映射,释放共享内存
void shmFree(void){
    // 释放信息表
    if (shmdt(shm_msgs) == -1) {
        perror("shmdt msgs failed");
        exit(-1);
    }
    if (shmctl(shmid_msg, IPC_RMID, 0) == -1) {
        perror("shmctl(IPC_RMID) msgs failed");
        exit(-1);
    }

    // 释放用户表
    if (shmdt(shm_users) == -1) {
        perror("shmdt users failed");
        exit(-1);
    }
    if (shmctl(shmid_user, IPC_RMID, 0) == -1) {
        perror("shmctl(IPC_RMID) users failed");
        exit(-1);
    }
}

// 往信息表特定索引项写入数据
void shmMsgWrite(unsigned int index, shm_msg_t *data){
    if(index >= SHM_MSG_SIZE){
        perror("index out(msg write)");
        exit(-1);
    }

    shmMsgWait();
    shm_msgs[index].src  = data->src;
    shm_msgs[index].dest = data->dest;
    strcpy(shm_msgs[index].msg, data->msg);
    shmMsgPost();
}

// 在信息表内找到空白项并插入数据
// 成功则返回索引号，否则返回-1
int shmMsgAppend(shm_msg_t *data){
    shmMsgWait();

    for(int i = 0; i < SHM_MSG_SIZE; i++){
        if(shm_msgs[i].dest == 0){
            shm_msgs[i].dest = data->dest;
            shm_msgs[i].src  = data->src;
            strcpy(shm_msgs[i].msg, data->msg);
            shmMsgPost();
            return i;
        }
    }

    shmMsgPost();
    return -1;
}

// 根据dest字段从信息表中读出数据并将表项设为空（dest设为0）
// 成功则返回索引号，否则返回-1
int shmMsgReadByDest(char dest, shm_msg_t *data){
    shmMsgWait();

    for(int i = 0; i < SHM_MSG_SIZE; i++){
        if(shm_msgs[i].dest == dest){
            data->dest = shm_msgs[i].dest;
            data->src  = shm_msgs[i].src;
            strcpy(data->msg, shm_msgs[i].msg);

            shm_msgs[i].dest = 0;
            shmMsgPost();
            return i;
        }
    }

    shmMsgPost();
    return -1;
}

// 根据索引号从信息表中读出数据，并将该项设为空（dest设为0）
void shmMsgReadByIndex(unsigned int index, shm_msg_t *data){
    if(index >= SHM_MSG_SIZE){
        perror("index out(msg read)");
        exit(-1);
    }

    shmMsgWait();
    data->dest = shm_msgs[index].dest;
    data->src  = shm_msgs[index].src;
    strcpy(data->msg, shm_msgs[index].msg);
    shm_msgs[index].dest = 0;
    shmMsgPost();
}

// 在用户表中找到空白项并插入数据
// 成功返回索引号，否则返回-1
// 用户id不允许为0或字符*，id不能重复
int shmUserAppend(char id, pid_t pid){
    int index = -1;

    if(id == 0 || id == '*')
        return -1;
    
    shmUserWait();
    for(int i = 0; i < SHM_USER_SIZE; i++){
        // printf("<test> shm_users[%d].id is %d\n", i, shm_users[i].id);
        if(shm_users[i].id == 0){
            if(index == -1)
                index = i;
        }else{
            if(shm_users[i].id == id){
                printf("<test> %c existed at %d\n", id, i);
                shmUserPost();
                return -1;
            }
        }
    }

    if(index != -1){
        printf("<test> add new user %c to shm_users[%d]\n", id, index);
        shm_users[index].id  = id;
        shm_users[index].pid = pid;
    }else
        printf("<test> shm_user is full\n");

    shmUserPost();
    return index;
}

// 根据id好从用户表中读出特定id的进程号
// 成功返回pid，否则返回-1
pid_t shmUserReadById(char id){
    shmUserWait();
    for(int i = 0; i < SHM_USER_SIZE; i++){
        if(shm_users[i].id == id){
            shmUserPost();
            return shm_users[i].pid;
        }
    }

    shmUserPost();
    return -1;
}

// 根据索引号从用户表中读出对应的进程号
// 成功返回pid，否则返回0
pid_t shmUserReadByIndex(char index, char *id){
    pid_t pid = 0;

    if(index >= SHM_USER_SIZE){
       printf("<test> index out(user read)\n");
       return 0;
    }

    shmUserWait();
    pid = shm_users[index].pid;
    *id = shm_users[index].id;
    shmUserPost();
    return pid;
}

// 根据id将用户表中的特定项删除（id置为0）
// 成功返回索引号，否则返回-1
int shmUserDelById(char id){
    if(id == 0)
        return -1;

    shmUserWait();
    for(int i = 0; i < SHM_USER_SIZE; i++){
        if(shm_users[i].id == id){
            shm_users[i].id = 0;
            
            shmUserPost();
            return i;
        }
    }

    shmUserPost();
    return -1;
}

// 统计用户表中当前在线的用户数量
int shmUserCount(void){
    int count = 0;

    shmUserWait();

    for(int i = 0; i < SHM_USER_SIZE; i++){
        if(shm_users[i].id != 0)
            count++;
    }

    shmUserPost();
    return count;
}