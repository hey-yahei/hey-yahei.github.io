#ifndef _MYSHM_H
#define _MYSHM_H

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

// 信息表和用户表的大小
#define SHM_MSG_SIZE  10
#define SHM_USER_SIZE 10

// 信息表和用户表的key
#define SHM_MSG_KEY  (key_t)1234
#define SHM_USER_KEY (key_t)4321

// 信息表表项定义
typedef struct shm_msg_t{
    char src;       // 源端标识符(单字符)
    char dest;      // 终端标识符(单字符)
    char msg[10];   // 传递的消息
} shm_msg_t;

// 用户表表项定义
typedef struct shm_user_t{
    char id;    // 用户id
    pid_t pid;  // 用户对应的pid
} shm_user_t;

extern int shmid_user;
extern int shmid_msg;
extern shm_user_t *shm_users;
extern shm_msg_t  *shm_msgs;
extern int semid_user;
extern int semid_msg;

void shmInit(void);
void shmFree(void);
void shmMsgWrite(unsigned int index, shm_msg_t *data);
int  shmMsgAppend(shm_msg_t *data);
int  shmMsgReadByDest(char dest, shm_msg_t *data);
void shmMsgReadByIndex(unsigned int index, shm_msg_t *data);
int  shmUserAppend(char id, pid_t pid);
pid_t shmUserReadById(char id);
pid_t shmUserReadByIndex(char index, char *id);
int  shmUserDelById(char id);
int  shmUserCount(void);


#endif // ~~_MYSHM_H