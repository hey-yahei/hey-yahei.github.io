/*
 * 嵌入式操作系统实验4 —— 多进程通信综合应用
 ****************************************************
 * 本文件为主程序，完成用户交互等工作；
 * 共享内存的相关数据结构和操作定义见myshm；
 * 信号量的相关数据结构和操作定义见mysem；
 ****************************************************
 * 编译说明
 * gcc mysem.c myshm.c talk.c -o talk
 ****************************************************
 * 使用说明
 * 1. 注册用户
 *    运行程序后需要输入用户名（单字符）进行注册，
 *    用户名不允许为\0或*，不允许与当前用户表内的用户重名；
 *    注册完用户后程序进入指令接收状态（支持指令如下所示）
 * 2. 查询在线用户表：list user
 * 3. 查询信息缓冲表：list msg
 * 4. 发送信息给特定用户：send <user> <message>
 *    如：send A 123，向A发送字符串123；
 *    指定用户为*时，表示向所有在线用户（排除自己）广播信息；
 *    字符串长度不能超过9个字符，否则会被程序自行截断；
 * 5. 退出：exit
 * 6. 强制释放资源并退出：free
 ****************************************************
 * 修改时间：2017-6-12 12:40:53
 ****************************************************
 * 作者：YaHei(zk)
 */

// 头文件---------------------------------------------
#include <stdio.h>          // printf(), scanf()
#include <string.h>         // strtok(), strcmp(), strcpy(), strlen()
#include <sys/types.h>      // pid_t
#include <signal.h>         // signal(), SIGUSR

#include "myshm.h"          // 共享内存（shm）相关的数据结构与操作
#include "mysem.h"          // 信号量（sem）相关的数据结构与操作
// ----------------------------------------------------

// 全局变量定义-----------------------------------------
// 共享内存
int shmid_user = -1;    // 用户表共享内存的id号
int shmid_msg  = -1;    // 信息表共享内存的id号
shm_user_t *shm_users;  // 用户表共享内存在本地的映射地址
shm_msg_t  *shm_msgs;   // 信息表共享内存在本地的映射地址
// 信号量
int semid_user = -1;    // 用户表共享内存访问控制的信号量
int semid_msg  = -1;    // 信息表共享内存访问控制的信号量
// 进程
char myid;              // 记录当前进程的id
// ----------------------------------------------------

// 本地函数声明-----------------------------------------
void printUserTable(void);
void printMsgTable(void);
void freeSources(void);
int  sendMessage(shm_msg_t *message);
// ----------------------------------------------------


// SIGUSR1信号的处理函数
void signalHandler(int signal_num){
    shm_msg_t message;  // 暂存信息项

    printf("<test> get signal\n");
    // 从信息表中查找发送给本进程的信息并打印出来
    if( shmMsgReadByDest(myid, &message) != -1){
        printf("[from %c] %s\n", message.src, message.msg);
        printf(">>>\n");
    }else{
        printf("get signal but message not found\n");
    }
}
// ------------------------------------------------------

void main(void){
    char command[50];       // 指令缓冲区
    char *s;                // 暂存指令分割的字符串
    char dest_id;           // 暂存目的用户的id号
    pid_t dest_pid;         // 暂存目的用户所在进程的pid
    shm_msg_t message;      // 暂存信息项
    
    semInit();  // 初始化信息量
    shmInit();  // 初始化共享内存
    signal(SIGUSR1, signalHandler);     // 将SIGUSR1绑定给本地的处理函数

    // 用户输入id进程注册
    printf("Input your id: ");
    scanf("%c", &myid);
    // 尝试进行注册
    while( shmUserAppend(myid, getpid()) == -1 ){   // 如果注册失败则不断循环
        printf("add user %c failed\n", myid);
        // 重新注册
        getchar();  // 读走上一个scanf遗留的换行符
        printf("Input your id: ");
        scanf("%c", &myid);
    }
    printf("=================\n");
    // 死循环
    for(;;){        
        getchar();      // 读走上一个scanf遗留的换行符
        // 等待指令的输入
        printf("> ");
        scanf("%[^\n]", command);       // 读取所有字符直到下一个换行符(可以读入空格)
        // printf("<test>get %s\n", command);
        // 以空格为分隔符分割指令和参数
        s = strtok(command, " ");
        if(s){  // 第一项参数（指令）存在
            // printf("<test>strtok1 : %s\n", s);
            if(!strcmp(s, "list")){     // list指令
                s = strtok(NULL, " ");
                if(s){  // 第二项参数存在
                    // printf("<test>strtok2 : %s\n", s);
                    if(!strcmp(s, "user")){ // list user：打印用户表
                        printUserTable();
                    }else if(!strcmp(s, "msg")){    // list msg：打印信息表
                        printMsgTable();
                    }else{  // 无效表格名称
                        printf("table not found\n");
                    }
                }else{  // 第二项参数不存在（即没有指明打印哪张列表）
                    printf("table is needed\n");
                }
            }else if(!strcmp(s, "send")){   // send指令
                s = strtok(NULL, " ");
                if(s){  // 第二项参数（信息的目的用户）存在
                    dest_id = s[0];
                    if( dest_id == myid ){      // 发送给自己
                        printf("cannot send message to self\n");
                    }else if( dest_id == '*' ){    // 发送给所有用户（除了自己）               
                        s = strtok(NULL, " ");
                        if(s){  // 第三项参数（信息的内容）存在
                            if(strlen(s) >= 10){    // 过长的信息：截断
                                printf("<test> message is too long.\n");
                                s[9] = '\0';
                            }
                            // 填充好源用户和信息内容
                            message.src = myid;
                            strcpy(message.msg, s);
                            // 遍历用户表，逐一发送给所有的有效用户
                            for(int i = 0; i < SHM_USER_SIZE; i++){
                                if( dest_pid = shmUserReadByIndex(i, &dest_id) ){
                                    if(dest_id != myid){    // 不发送给自己
                                        // 填充目的用户并发送
                                        message.dest = dest_id;
                                        sendMessage(&message);
                                    }
                                }
                            }
                        }else{  // 第三项参数不存在（即没有指明发送的信息内容）
                            printf("<failed> msg is needed\n");
                        }
                    // 即不是自己也不是*，那么就是发送给特定用户
                    }else if( shmUserReadById(dest_id) == -1 ){     // 用户不存在
                        printf("user %c not found\n", s[0]);
                    }else{  // 用户存在
                        // 填充源用户和目的用户
                        message.dest = dest_id;
                        message.src  = myid;
                        // 截取获得信息内容
                        s = strtok(NULL, " ");
                        if(s){  // 第三项参数（信息的内容）存在
                            if(strlen(s) >= 10){    // 信息的内容过长，则截断
                                printf("<test> message is too long.\n");
                                s[9] = '\0';
                            }
                            // 填充信息内容并尝试发送
                            strcpy(message.msg, s);
                            if(sendMessage(&message) != -1)     // 发送成功
                                printf("send -> succeed\n");
                            else    // 发送失败
                                printf("send -> failed\n");
                        }else{  // 第三项参数不存在（即没有指明信息的内容）
                            printf("<failed> msg is needed\n");
                        }
                    }
                }else{  // 第二项参数不存在（即没有指明信息的目的用户）
                    printf("<failed> user is needed\n");
                }
            }else if(!strcmp(s, "exit")){   // exit指令
                // 直接退出循环（如果是最后一个用户，则将释放资源）
                break;
            }else if(!strcmp(s, "free")){   // free指令
                // 无论是否是最后一个用户，都将资源释放并结束进程
                freeSources();
                printf("free all sources and exit\n");
                exit(0);
            }else{      // 非法指令
                printf("command %s invalid\n", command);
            }
        }else{  // 第一项参数不存在（即未找到指令字符串）
            printf("command not found\n");
        }
    }   // ~~ for(;;)
    
    // 如果for循环被break，说明用户执行了exit
    // 将自己从用户表中删除
    shmUserDelById(myid);
    // 尝试释放资源
    if(shmUserCount() == 0){    // 删除后用户表内已经没有用户，那么释放资源
        printf("last user, free all sources\n");
        freeSources();
    }else{  // 如果还有用户，则打印出剩余用户的数量
        printf("%d users left\n", shmUserCount());
    }
}
// ------------------------------------------------------

// 打印用户表格
void printUserTable(void){
    shmUserWait();
    printf("==========================\n");
    printf("<user table>\n");
    printf("id  |  pid\n");
    for(int i = 0; i < SHM_USER_SIZE; i++){
        printf("%c | %d\n", shm_users[i].id, shm_users[i].pid);
    }
    printf("==========================\n");
    shmUserPost();
}
// ------------------------------------------------------

// 打印信息表格
void printMsgTable(void){
    shmMsgWait();
    printf("==========================\n");
    printf("<msg table>\n");
    printf("dest | src | msg\n");
    for(int i = 0; i < SHM_MSG_SIZE; i++){
        printf("%c   | %c  | %s\n", shm_msgs[i].dest, shm_msgs[i].src, shm_msgs[i].msg);
    }
    printf("==========================\n");
    shmMsgPost();
}
// ------------------------------------------------------

// 释放资源
void freeSources(void){
    semFree();
    shmFree();
}

// 发送信息
int sendMessage(shm_msg_t *message){
    int ret;        // 暂存shmMsgAppend()的返回值
    pid_t dest_pid; // 暂存目的用户所在进程的pid

    ret = shmMsgAppend(message);    // 尝试往信息表中插入新的信息
    if(ret == -1)   // 信息表已满
        printf("<failed> shm_msg is full\n");
    else{   // 信息表未满
        printf("add msg \"%s\"(from %c to %c) to shared memory[%d]\n", 
                message->msg, message->src, message->dest, ret);
        // 获取目的用户所在进程的pid
        dest_pid = shmUserReadById(message->dest);
        if(dest_pid != -1){ // 成功获取pid
            // 向目的用户所在进程发送SIGUSR1信号提醒其查阅信息
            kill(dest_pid, SIGUSR1);
            printf("send signal SIGUSR1 to %c whose pid is %d\n", message->dest, dest_pid);
        }
    }

    return ret;
}
